import enums.FoodPreference;
import org.junit.jupiter.api.Test;
import java.io.IOException;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class PairControllerTest {
    @Test
    void testAllPairsHaveKitchen() throws IOException {
        CSVReader reader = new CSVReader("./src/main/resources/teilnehmerliste.csv");
        PairController pairController = new PairController(reader.initialParticipants, 1, 10, 5);


        List<Pair> pairs = pairController.finalPairs;

        boolean allKitchen = true;
        for (Pair p : pairs) {
            if (p.getKitchen() == null) {
                allKitchen = false;
            }
        }
        // Assert that all pairs in the finalPairs list have kitchens
        assertTrue(allKitchen);
    }

    @Test
    void checkFoodPrefrence()  throws IOException {
        CSVReader reader = new CSVReader("./src/main/resources/teilnehmerliste.csv");
        PairController pairController = new PairController(reader.initialParticipants, 1, 10, 5);


        List<Pair> pairs = pairController.finalPairs;


        for (Pair p : pairs) {
            Participant participant1 = p.getFirstParticipant();
            Participant participant2 = p.getSecondParticipant();
            if(participant1.foodPreference != FoodPreference.NONE && participant2.foodPreference != FoodPreference.NONE) {
                if (participant1.foodPreference != FoodPreference.VEGAN && participant2.foodPreference != FoodPreference.VEGGIE){
                    if(participant1.foodPreference != FoodPreference.VEGGIE && participant2.foodPreference != FoodPreference.VEGAN){
                        assertEquals(participant1.foodPreference,participant2.foodPreference);
                    }
                }
            }
        }
    }

    @Test
    void calculateWeightedScore() throws IOException {
        CSVReader reader = new CSVReader("./src/main/resources/teilnehmerliste.csv");
        PairController pairController = new PairController(reader.initialParticipants, 1, 10, 5);


        List<Pair> pairs = pairController.finalPairs;


        for (Pair p : pairs) {
            double weightedScore = p.calculateWeightedScore(1,10,5);
            if(weightedScore>0.0){
                assertTrue(weightedScore > 0.0);
            }
        }
    }

    @Test
    void calculateGenderDiff() throws IOException {
        CSVReader reader = new CSVReader("./src/main/resources/teilnehmerliste.csv");
        PairController pairController = new PairController(reader.initialParticipants, 1, 10, 5);


        List<Pair> pairs = pairController.finalPairs;


        for (Pair p : pairs) {
            double genderDiff = p.calculateGenderDiff();
            if(genderDiff>0.0){
                assertTrue(genderDiff > 0.0);
            }
        }
    }
}