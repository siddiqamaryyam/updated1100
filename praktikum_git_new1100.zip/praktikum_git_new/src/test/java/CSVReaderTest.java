import org.junit.Assert;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;

class CSVReaderTest {
    /**
     * Tests the validity of a CSV file.
     * It verifies that the file can be successfully read
     * and the first line is not null.
     * This test ensures that the file is accessible and contains data.
     *
     * @throws IOException if an exception occurs while reading the file.
     */
    @Test
    public void testValidCSVFile() {
        String fileName = "./src/main/resources/teilnehmerliste.csv";
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String firstLine = reader.readLine();
            Assertions.assertNotNull(firstLine);
        } catch (IOException e) {
            Assertions.fail("An exception occurred while reading the file: " + e.getMessage());
        }
    }
    /**
     * Tests an empty CSV file.
     * It verifies that the file can be successfully read
     * and the first line is not empty.
     * This test ensures that the file is accessible and contains data,
     * even if it's just a header line.
     *
     * @throws IOException if an exception occurs while reading the file.
     */
    @Test
    public void testEmptyCSVFile() {
        String fileName = "./src/main/resources/teilnehmerliste.csv";
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String firstLine = reader.readLine();
            Assertions.assertFalse(firstLine.isEmpty());
        } catch (IOException e) {
            Assertions.fail("An exception occurred while reading the file: " + e.getMessage());
        }
    }

    /**
     * Tests the participant .
     * It reads the CSV file and verifies that the number of lines
     * is greater than the number of initial participants.
     * This test ensures that the file contains participant data
     * and is being read correctly.
     *
     * @throws IOException if an exception occurs while reading the file.
     */
    @Test
    public void testParticipantCSVFile() {
        String fileName = "./src/main/resources/teilnehmerliste.csv";

        try (FileReader fileReader = new FileReader(fileName);
             BufferedReader bufferedReader = new BufferedReader(fileReader)) {
            CSVReader csvReader = new CSVReader(fileName);
            int lineCount = 0;
            while (bufferedReader.readLine() != null) {
                lineCount++;
            }
            Assertions.assertTrue(lineCount > csvReader.initialParticipants.size(), "Participants test passed");
        } catch (IOException e) {
            Assertions.fail("An exception occurred while reading the file: " + e.getMessage());
        }
    }
    @Test
    public void testCSVFileWithMissingColumns() {
        String fileName = "./src/main/resources/teilnehmerliste.csv";
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            // Read the header line of the CSV file
            String headerLine = reader.readLine();

            // Assert that the header line is not null or empty
            Assertions.assertNotNull(headerLine);
            Assertions.assertFalse(headerLine.isEmpty());

            // Split the header line into column names
            String[] columns = headerLine.split(",");
            // Assert that the expected columns are present in the header line
            Assertions.assertTrue(columnExists(columns, "ID"));
            Assertions.assertTrue(columnExists(columns, "Name"));
            Assertions.assertTrue(columnExists(columns, "FoodPreference"));
            Assertions.assertTrue(columnExists(columns, "Age"));
            Assertions.assertTrue(columnExists(columns, "Sex"));
            Assertions.assertTrue(columnExists(columns, "Kitchen"));
            Assertions.assertTrue(columnExists(columns, "Kitchen_Story"));
            Assertions.assertTrue(columnExists(columns, "Kitchen_Longitude"));
            Assertions.assertTrue(columnExists(columns, "Kitchen_Latitude"));
            Assertions.assertTrue(columnExists(columns, "ID_2"));
            Assertions.assertTrue(columnExists(columns, "Name_2"));
            Assertions.assertTrue(columnExists(columns, "Age_2"));
            Assertions.assertTrue(columnExists(columns, "Sex_2"));

        } catch (IOException e) {
            Assertions.fail("An exception occurred while reading the file: " + e.getMessage());
        }
    }
    private boolean columnExists(String[] columns, String columnName) {
        for (String column : columns) {
            if (column.trim().equalsIgnoreCase(columnName)) {
                return true;
            }
        }
        return false;
    }
    @Test
    public void testPathFile() {
        String fileName = "./src/main/resources/partylocation.csv";
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String firstLine = reader.readLine();
            Assertions.assertNotNull(firstLine);
        } catch (IOException e) {
            Assertions.fail("An exception occurred while reading the file: " + e.getMessage());
        }
    }
    @Test
    public void testPairsCSVFile() {
        // Arrange
        String fileName = "./src/main/resources/teilnehmerliste.csv"; // Update with the path to your sample CSV file

        try {
            CSVReader csvReader = new CSVReader(fileName);

            // Act
            List<Pair> pairs = csvReader.initialPairs;

            // Assert
            Assertions.assertNotNull(pairs, "The list of pairs should not be null.");
            Assertions.assertFalse(pairs.isEmpty(), "The list of pairs should not be empty.");

            for (Pair pair : pairs) {
                Assertions.assertTrue(pair.hasPair(), "Each pair should have a second participant.");
                Assertions.assertNotNull(pair.getParticipant1(), "Participant 1 should not be null.");
                Assertions.assertNotNull(pair.getParticipant2(), "Participant 2 should not be null.");
            }

            // Additional assertions can be added based on the specific requirements of the Pair class or Participant class

        } catch (IOException e) {
            Assertions.fail("An exception occurred while reading the file: " + e.getMessage());
        }
    }


}


