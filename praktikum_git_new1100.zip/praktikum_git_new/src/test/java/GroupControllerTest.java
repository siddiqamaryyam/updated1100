import static org.junit.jupiter.api.Assertions.*;
import enums.Course;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;


class GroupControllerTest {
    @Test
    void calculatePathLength() throws IOException {
        List<Group> groups = new ArrayList<>();
        CSVReader csvReader = new CSVReader("./src/main/resources/teilnehmerliste.csv");

        Group group = new Group(Course.FIRST, csvReader.initialPairs.get(1), csvReader.initialPairs.get(2), csvReader.initialPairs.get(3));

        // Add the group to the list
        groups.add(group);

        // Specify the party location coordinates
        Location partyLocation = new Location(40.7128, -74.0060);  // Example: New York City coordinates

        // Manually calculate the expected path length based on the coordinates and group locations
        double expectedPathLength = Main.haversine(csvReader.initialPairs.get(1).getKitchen().getLatitude(), csvReader.initialPairs.get(1).getKitchen().getLongitude(), csvReader.initialPairs.get(2).getKitchen().getLatitude(), csvReader.initialPairs.get(2).getKitchen().getLongitude());
        expectedPathLength += Main.haversine(csvReader.initialPairs.get(2).getKitchen().getLatitude(), csvReader.initialPairs.get(2).getKitchen().getLongitude(), csvReader.initialPairs.get(3).getKitchen().getLatitude(), csvReader.initialPairs.get(3).getKitchen().getLongitude());
        expectedPathLength += Main.haversine(csvReader.initialPairs.get(3).getKitchen().getLatitude(), csvReader.initialPairs.get(3).getKitchen().getLongitude(), partyLocation.getLatitude(), partyLocation.getLongitude());

        // Calculate the actual path length using the calculatePathLength() method
        double actualPathLength = GroupController.calculatePathLength(groups, partyLocation);

        // Assert the expected path length matches the actual path length
        System.out.println("expectedPathLength: "+expectedPathLength);
        System.out.println("actualPathLength: "+actualPathLength);

        assertTrue(Math.abs(actualPathLength - expectedPathLength) > 0.001, "Incorrect path length");
    }
    @Test
    void checkSolutions() throws IOException {
        CSVReader reader = new CSVReader("./src/main/resources/teilnehmerliste.csv");


        PairController pairController = new PairController(reader.initialParticipants, 1    , 10, 5);

        List<Pair> resultingPairs = new ArrayList<>(Stream.concat(reader.initialPairs.stream(), pairController.finalPairs.stream()).toList());

        Location partyLocation = Location.readFromCsv();
        assert partyLocation != null;

        GroupController groupController = new GroupController(resultingPairs, partyLocation, 1, 10, 5);

        List<Group> groupList = groupController.finalGroups;
        assertTrue(Main.getAverageAgeDiff(groupList) > 0, "Incorrect Average Age Difference");
        assertTrue(Main.getAverageGenderDiff(groupList) > 0, "Incorrect Gender Difference");
        assertTrue(Main.getPreferenceDeviation(groupList) > 0, "Incorrect Preference Deviation");
    }
    @Test
    void isAllPairsCooking() throws IOException {
        CSVReader reader = new CSVReader("./src/main/resources/teilnehmerliste.csv");

        PairController pairController = new PairController(reader.initialParticipants, 1    , 10, 5);

        List<Pair> resultingPairs = new ArrayList<>(Stream.concat(reader.initialPairs.stream(), pairController.finalPairs.stream()).toList());

        Location partyLocation = Location.readFromCsv();
        assert partyLocation != null;

        GroupController groupController = new GroupController(resultingPairs, partyLocation, 1, 10, 5);
        List<Group> finalGroups = groupController.finalGroups;


        for (Pair pair : resultingPairs) {
            boolean isCooking = true;
            for (Group group : finalGroups) {
                if (group.getCookingPair().hasPair()) {
                    isCooking = false;
                    break;
                }
            }
            // Assert that the pair is cooking at least once
            assertTrue(true, "Pair is not cooking in any group");
        }

    }
}