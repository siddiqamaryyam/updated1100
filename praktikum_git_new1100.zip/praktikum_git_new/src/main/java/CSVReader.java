import enums.FoodPreference;
import enums.Gender;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVRecord;

import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class CSVReader {
    List<Participant> initialParticipants = new ArrayList<>();
    List<Pair> initialPairs = new ArrayList<>();

    public CSVReader(String fileName) throws IOException {
        FileReader reader = new FileReader(fileName);
        Iterable<CSVRecord> records = CSVFormat.DEFAULT.withFirstRecordAsHeader().parse(reader);
        for (CSVRecord record : records) {
            String id = record.get("ID");
            String name = record.get("Name");
            FoodPreference foodPreference = parseFoodPreference(record.get("FoodPreference"));
            int age = Integer.parseInt(record.get("Age"));
            Gender sex = parseGender(record.get("Sex"));
            String kitchenAvailable = record.get("Kitchen");
            double kitchenStory = parseDouble(record.get("Kitchen_Story"));
            double kitchenLongitude = parseDouble(record.get("Kitchen_Longitude"));
            double kitchenLatitude = parseDouble(record.get("Kitchen_Latitude"));
            Kitchen kitchen = switch (kitchenAvailable) {
                case "yes" -> new Kitchen(false, (int)kitchenStory, kitchenLongitude, kitchenLatitude);
                case "maybe" -> new Kitchen(true, (int)kitchenStory, kitchenLongitude, kitchenLatitude);
                default -> null;
            };
            Participant participant = new Participant(id, name, foodPreference, age, sex, kitchen);

            String id2 = record.get("ID_2");
            if(!id2.isBlank()) {
                Participant participant2 = new Participant(
                        id2,
                        record.get("Name_2"),
                        foodPreference,
                        (int)parseDouble(record.get("Age_2")),
                        parseGender(record.get("Sex_2")),
                        null);
                initialPairs.add(new Pair(true, participant, participant2));
            } else {
                this.initialParticipants.add(participant);
            }
        }
    }

    private static FoodPreference parseFoodPreference(String foodPreferenceString) {
        return switch (foodPreferenceString) {
            case "none" -> FoodPreference.NONE;
            case "meat" -> FoodPreference.MEAT;
            case "veggie" -> FoodPreference.VEGGIE;
            case "vegan" -> FoodPreference.VEGAN;
            default -> null;
        };
    }

    private static Gender parseGender(String genderString) {
        return switch (genderString) {
            case "female" -> Gender.FEMALE;
            case "male" -> Gender.MALE;
            case "other" -> Gender.OTHER;
            default -> null;
        };
    }

    private static double parseDouble(String doubleString) {
        try {
            return Double.parseDouble(doubleString);
        } catch (NumberFormatException e) {
            return 0.0;
        }
    }
}
