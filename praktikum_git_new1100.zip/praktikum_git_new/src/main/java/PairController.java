import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class PairController {
    static List<Pair> finalPairs = new ArrayList<>();
    List<Participant> successorParticipants = new ArrayList<>();

    public PairController(List<Participant> participants, int foodWeight, int genderWeight, int ageWeight) {
        List<Participant> noKitchenParticipants = participants.stream()
                .filter(p -> p.getKitchen() == null)
                .toList();

        List<Participant> kitchenParticipants = new ArrayList<>(participants.stream()
                .filter(p -> p.getKitchen() != null)
                .toList());
        kitchenParticipants.sort(Comparator.comparing(p -> p.getKitchen().getEmergencyKitchen()));

        List<Participant> mappedParticipants = new ArrayList<>();
        List<Pair> mappedPairs = new ArrayList<>();

        for (int i = 0; i < kitchenParticipants.size(); i++) {
            int finalI = i;
            List<Participant> possibleParticipants = new ArrayList<>(noKitchenParticipants.stream()
                    .filter(p -> !mappedParticipants.contains(p))
                    .filter(p -> kitchenParticipants.get(finalI).isPossibleMatch(p))
                    .toList());

            List<Pair> possiblePairs = new ArrayList<>(possibleParticipants.stream().map(p -> new Pair(false, kitchenParticipants.get(finalI), p)).toList());

            possiblePairs.sort(Comparator.comparingDouble((Pair p) -> p.calculateWeightedScore(foodWeight, genderWeight, ageWeight)));

            if (possiblePairs.size() > 0) {
                mappedParticipants.add(possibleParticipants.get(0));
                mappedParticipants.add(kitchenParticipants.get(finalI));
                mappedPairs.add(possiblePairs.get(0));
            }
        }

        List<Participant> remainingParticipants = new ArrayList<>(participants);
        remainingParticipants.removeAll(mappedParticipants);

        while (remainingParticipants.size() > 1) {
            mappedPairs.add(new Pair(false, remainingParticipants.get(0), remainingParticipants.get(1)));
            remainingParticipants.remove(0);
            remainingParticipants.remove(0);
        }

        finalPairs.addAll(mappedPairs);
        successorParticipants.addAll(remainingParticipants);
    }

    // test
    // Auf der Pairlist aufrufen und testen ob:
    //Datenfelder
    //CSVReader reader = new CSVReader("./src/main/resources/teilnehmerliste.csv");
    //List<Participant> participants = reader.initialParticipants;
    //int foodWeight = 1;
    //int genderWeight = 10;
    //int ageWeight = 5;
    // PairController controller = new PairController(participants, foodWeight, genderWeight, ageWeight)

    // test 1: testet ob alle Küche haben
    // List<Pair> pairs = controller.finalPairs;
    // boolean allKitchen = true;
    // for(Pair p: pairs) {
        // if (p.getKitchen() == null) {
        // allKitchen = false;
        //}
    //}
    //Assertation.assertTrue(allKitchen);

    // Test 2: vegan mit fleischi
    // List<Pair> pairs = controller.finalPairs;
    // boolean foodOK = true;
    // for(Pair p: pairs) {
    // FoodPrefrence foodpref1 = p.getFirstParticipant();
    // FoodPrefrence foodpref2 = p.getSecondParticipant();
    // if (foodpref1 == meat) {
    //  if (foodpref2 == vegan) {
        // foodOK = false;
    // if (foodpref1 == vegan)
        //  if (foodpref2 == meat) {
            // foodOK = false;
    //Assertation.assertTrue(foodOK);







}
