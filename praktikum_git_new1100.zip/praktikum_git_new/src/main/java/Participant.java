import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import enums.FoodPreference;
import enums.Gender;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "id", "name", "foodPreference", "age", "gender", "kitchen" })
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY, getterVisibility = JsonAutoDetect.Visibility.NONE, setterVisibility = JsonAutoDetect.Visibility.NONE)
public class Participant {
    @JsonProperty("id")
    public String id;
    @JsonProperty("name")
    public String name;
    @JsonProperty("foodPreference")
    public FoodPreference foodPreference;
    @JsonProperty("age")
    public Integer age;
    @JsonProperty("gender")
    public Gender gender;

    @JsonProperty("kitchen")
    public Kitchen kitchen;

    public Participant(String id, String name, FoodPreference foodPreference, Integer age, Gender gender, Kitchen kitchen) {
        this.id = id;
        this.name = name;
        this.foodPreference = foodPreference;
        this.age = age;
        this.gender = gender;
        this.kitchen = kitchen;
    }

    @Override
    public String toString() {
        ObjectMapper mapper = new ObjectMapper();

        try {
            // Convert the Pair object to a JSON string
            return mapper.writeValueAsString(this);
        } catch (JsonProcessingException e) {
            // If there is an error in the conversion process, return a simple string representation
            return super.toString();
        }
    }

    public int ageRange() {
        if (age <= 17) {
            return 0;
        } else if (age <= 23) {
            return 1;
        } else if (age <= 27) {
            return 2;
        } else if (age <= 30) {
            return 3;
        } else if (age <= 35) {
            return 4;
        } else if (age <= 41) {
            return 5;
        } else if (age <= 46) {
            return 6;
        } else if (age <= 56) {
            return 7;
        }
        return 8;
    }

    public Kitchen getKitchen() {
        return kitchen;
    }

    public Gender getGender() {
        return gender;
    }

    public int ageScore(Participant other) {
        return -(Math.abs(ageRange() - other.ageRange()));
    }

    public int genderScore(Participant other) {
        if (this.gender != other.gender) {
            return 1;
        }
        return 0;
    }

    public int foodScore(Participant other) {
        if((this.foodPreference == other.foodPreference)
                || (this.foodPreference == FoodPreference.MEAT && other.foodPreference == FoodPreference.NONE)
                || (this.foodPreference == FoodPreference.NONE && other.foodPreference == FoodPreference.MEAT)) {
            return 1;
        }
        return 0;
    }

    public boolean isPossibleMatch(Participant other) {
        // return false if the FoodPreference of one is MEAT and the other is either VEGAN or VEGETARIAN and vice versa
        if ((this.foodPreference == FoodPreference.MEAT && other.foodPreference == FoodPreference.VEGAN)
        || (this.foodPreference == FoodPreference.VEGAN && other.foodPreference == FoodPreference.MEAT)
        || (this.foodPreference == FoodPreference.MEAT && other.foodPreference == FoodPreference.VEGGIE)
        || (this.foodPreference == FoodPreference.VEGGIE && other.foodPreference == FoodPreference.MEAT)) {
            return false;
        }

        return true;
    }

    public int getPreference() {
        int preferenceInt = -1;
        if (foodPreference != null) {
            if (!foodPreference.equals(FoodPreference.MEAT) && foodPreference != FoodPreference.NONE) {
                if (foodPreference.equals(FoodPreference.VEGGIE)) {
                    preferenceInt = 1;
                } else if (foodPreference.equals(FoodPreference.VEGAN)) {
                    preferenceInt = 2;
                }
            } else {
                preferenceInt = 0;
            }
        }

        return preferenceInt;
    }
}

