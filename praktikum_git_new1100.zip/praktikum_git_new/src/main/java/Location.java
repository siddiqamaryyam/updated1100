import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import static java.lang.Double.parseDouble;

public class Location {
    private double latitude;

    private double longitude;

    public double getLatitude() {
        return latitude;
    }

    public double getLongitude() {
        return longitude;
    }


    public Location(double latitude, double longitude) {
        this.latitude = latitude;
        this.longitude = longitude;
    }

    public static Location readFromCsv() {
        String line = "";

        try (BufferedReader br = new BufferedReader(new FileReader("./src/main/resources/partylocation.csv"))) {

            // Skip the first line (header)
            br.readLine();

            if ((line = br.readLine()) != null) {

                // use comma as separator
                String[] coordinates = line.split(",");

                return new Location(parseDouble(coordinates[1]), parseDouble(coordinates[0]));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }
}
