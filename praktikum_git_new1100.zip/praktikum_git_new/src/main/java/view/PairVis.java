package view;

import javax.swing.*;
import java.util.List;

public class PairVis {
    private JTable fielOne;
    //private List<Pair> pairs;

    //CSVReader reader = new CSVReader("./src/main/resources/teilnehmerliste.csv");
    //List<Participant> participants = reader.initialParticipants;
    //int foodWeight = 1;
    //int genderWeight = 10;
    //int ageWeight = 5;

    //PairController controller = new PairController(participants, foodWeight, genderWeight, ageWeight);

    //int tableSize = controller.finalPairs.size();
    // for(Pair p: controller.finalPairs) {
    





}
