package enums;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;

import java.io.IOException;

public class LowercaseEnumSerializer extends StdSerializer<Enum<?>> {

    public LowercaseEnumSerializer() {
        super(Enum.class, false);
    }

    @Override
    public void serialize(Enum<?> value, JsonGenerator gen, SerializerProvider provider) throws IOException {
        if (value == null) {
            provider.defaultSerializeNull(gen);
        } else {
            gen.writeString(value.name().toLowerCase());
        }
    }
}
