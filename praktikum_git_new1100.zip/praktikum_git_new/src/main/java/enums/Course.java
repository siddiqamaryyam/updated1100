package enums;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;

@JsonSerialize(using = LowercaseEnumSerializer.class)
public enum Course {FIRST, MAIN, DESSERT}
